//Touch0
#define Clear_160 myGLCD.print("                                                                                                                                                                  ", CENTER, 160);
#define Configuring_system_components "Hac""\xA4""po""\x9E""\x9F""a ""\x9F""o""\xA1""\xA3""o""\xA2""e""\xA2""\xA4""o""\x97"" ""c""\x9D""c""\xA4""e""\xA1""\xAB" //Настройка компонентов системы
#define Manual_heater_control "Py""\xA7""\xA2""oe y""\xA3""pa""\x97""\xA0""e""\xA2""\x9D""e ""\xA4""\xAD""\xA2""o""\xA1"//Ручное управление тэном
#define Create_a_recipe_Beer_brewing "Co""\x9C\x99""a""\xA2\x9D""e pe""\xA6""e""\xA3\xA4""a. Bap""\x9F""a ""\xA3\x9D\x97""a"//Создание рецепта. Варка пива
#define Recipes "Pe""\xA6""e""\xA3""\xA4""\xAB"//Рецепты
//Screen2
#define ON "BK""\x88"//ВКЛ
#define Mode "Pe""\x9B""\x9D""\xA1"//Режим
#define Heater "T""\x93""H"//ТЭН
#define Output "Mo""\xA9""\xA2""oc""\xA4""\xAC"" %"// Мощность %
#define OFF "B""\x91""K""\x88"// ВЫКЛ
//Screen4
#define Mashing "\x85""a""\xA4""\x9D""pa""\xA2""\x9D""e"// затирание
#define Warm_up "Ha""\x98""pe""\xA4""\xAC"//Нагреть
#define Pause "\x89""ay""\x9C""a"//Пауза
#define MashOut "Me""\xA8""ay""\xA4"//Мешаут
#define Temperature "Te""\xA1""\xA3""epa""\xA4""ypa"//Температура
#define Time_ "Bpe""\xA1""\xAF"//Время
//Screen4_1
#define Boiling "K""\x9D""\xA3""\xAF""\xA7""e""\xA2""\x9D""e"//Кипячение
#define Boil "K""\x9D""\xA3""\xAF""\xA4""\x9D""\xA4""\xAC"//Кипятить
#define Hop "X""\xA1""e""\xA0""\xAC"//Хмель
#define Cool_down "Ox""\xA0""a""\x99""\x9D""\xA4""\xAC"//Охладить
//Screen4_2
#define Recipe "Pe""\xA6""e""\xA3""\xA4"":"//Рецепт:
#define Heat_water_to "Ha""\x98""pe""\xA4""\xAC"" ""\x97""o""\x99""y"" ""\x99""o"//Нагреть воду до
#define Degree "\x7F""C"//значёк градуса
#define to_fall_asleep_with_malt "\x9C""ac""\xAB""\xA3""a""\xA4""\xAC"" ""co""\xA0""o""\x99""."//засыпать солод
#define Withstand_at "B""\xAB""\x99""ep""\x9B""a""\xA4""\xAC"" ""\xA3""p""\x9D"//Выдержать при
#define during "\x97"" ""\xA4""e""\xA7""e""\xA2""\x9D""e"" "//в течении
#define minutes "\xA1""\x9D""\xA2""y""\xA4"//минут
#define Create_recipe "Co""\x9C\x99""a""\xA4\xAC"" pe""\xA6""e""\xA3\xA4"//Создать рецепт
#define Continue_recipe "\x89""po""\x99""o""\xA0\x9B\x9D\xA4\xAC"" pe""\xA6""e""\xA3\xA4"//Продолжить рецепт
#define Start_brewing_beer "Ha""\xA7""a""\xA4\xAC"" ""\x97""ap""\x9D\xA4\xAC"" ""\xA3\x9D\x97""o?"//Начать варить пиво?
#define Yes "\x82""a"//Да
#define No  "He""\xA4"//Нет
